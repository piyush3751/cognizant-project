package org.cts.services;


import org.cts.model.Requirement;

public interface ReqServices {
	
	boolean reqUpload(Requirement requirement);
	
	boolean reqEdit(Requirement requirement);

}