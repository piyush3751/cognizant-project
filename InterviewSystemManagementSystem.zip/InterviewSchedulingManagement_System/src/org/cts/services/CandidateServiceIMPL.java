package org.cts.services;

import org.cts.dao.CandidateDao;
import org.cts.dao.CandidateDaoIMPL;
import org.cts.model.Candidate;

public class CandidateServiceIMPL implements CandidateService {
	CandidateDao dao= new CandidateDaoIMPL();
	
	@Override
	public boolean registerCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		return dao.register(candidate);
	}

}