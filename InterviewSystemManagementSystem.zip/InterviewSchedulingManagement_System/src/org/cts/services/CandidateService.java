package org.cts.services;

import org.cts.model.Candidate;

public interface CandidateService {
	boolean registerCandidate(Candidate candidate);
	
}