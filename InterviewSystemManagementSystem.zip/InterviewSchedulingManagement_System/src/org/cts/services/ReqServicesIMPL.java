package org.cts.services;

import org.cts.dao.AddRequirementDao;
import org.cts.dao.AddRequirementDaoIMPL;
import org.cts.model.Requirement;

public class ReqServicesIMPL implements ReqServices {
	AddRequirementDao dao1 = new AddRequirementDaoIMPL();

	@Override
	public boolean reqUpload(Requirement requirement) {
		// TODO Auto-generated method stub
		return dao1.addRequire(requirement);
	}

	@Override
	public boolean reqEdit(Requirement requirement) {
		// TODO Auto-generated method stub
		return dao1.editRequire(requirement);
	}

}