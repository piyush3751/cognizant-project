package org.cts;

import java.io.IOException;

import org.cts.dao.InterviewDao;
import org.cts.dao.InterviewDaoIMPL;
import org.cts.dao.ObservationDao;
import org.cts.dao.ObservationDaoIMPL;
import org.cts.model.Candidate;
import org.cts.model.Interview;
import org.cts.model.Observation;
import org.cts.model.Requirement;
import org.cts.services.CandidateService;
import org.cts.services.CandidateServiceIMPL;
import org.cts.services.ReqServices;
import org.cts.services.ReqServicesIMPL;
import org.cts.util.CandidateRankUtil;
import org.cts.util.InterviewModeUtil;
import org.cts.util.InterviewResultUtil;



public class Test {
	public final static String canRank =  CandidateRankUtil.calcRank();
	
	public static void main(String[] args) throws NumberFormatException, IOException
	{
		CandidateService service= new CandidateServiceIMPL();
		Candidate cd1 = new Candidate("piyush", "choudhary", "abcd", "22/03/1997", "jjn", "jhunjhunu", "Rajasthan", 333001, "9996159273", "BTECH", 2021, "65", "pjhajharia59@gmail.com", "PE", 5, "No history");
		boolean b= service.registerCandidate(cd1);
		if(b)
		{
			System.out.println("Registered Successfully!!");
		}
		else {
			System.out.println("Resgistration Unsuccessful!!");
		}
		System.out.print("Rank of the candidate is: ");
		System.out.println(canRank);
		
		//requirement 2 and 3
		ReqServices rService = new ReqServicesIMPL();
		InterviewModeUtil mod = new InterviewModeUtil();
		Requirement req1 = new Requirement("3", "30-07-2021", 4, "PE", "medium", 123457, 1);
		Requirement req2 = new Requirement("4", "30-07-2021", 5, "PE", "medium", 123457, 1);
		boolean c= rService.reqUpload(req1);
		if(c)
		{
			System.out.println("Requirement details uploaded Successfully!!");
			System.out.print("Mode of Interview: ");
			System.out.println(mod.modeOfInterview(req1));
		}
		else
			{
				System.out.println("Requirement details uploading Unsuccessful!!!");
			}
		boolean d= rService.reqEdit(req2);
		if(d)
		{
			System.out.println("Requirement details edited Successfully!!");
			System.out.print("Mode of Interview: ");
			System.out.println(mod.modeOfInterview(req2));
		}
		else
			{
				System.out.println("Requirement details editing Unsuccessful!!!");
			}
		
		
		//requirement 4
		Interview in = new Interview(121, 1, "KOLKATA",1);
		InterviewDao da = new InterviewDaoIMPL();
		boolean e = da.scheduleInterview(in);
		System.out.println(e);
		if(e)
		{
			System.out.println("Interview is Scheduled successfully");
		}
		
		//requirement5
		ObservationDao oda = new ObservationDaoIMPL();
		InterviewResultUtil irs = new InterviewResultUtil();
		Observation ob = new Observation(1, 1, 79, "15 Days");
		int status = InterviewResultUtil.status;
		
		System.out.println("Result and status of the candidate is: ");
		String interResult = irs.result();
		
		System.out.println(interResult + " and " +status + " respectively");
		
		boolean f = oda.storeObservation(ob);
		if(f)
		{
			System.out.println("Interview observations are stored successfully!!");
		}
		else {
			System.out.println("Storing interview observations is Unsuccessful!!");
		}
		
		
		
		
		
	}
}