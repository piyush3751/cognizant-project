package org.cts.dao;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cts.Test;
import org.cts.model.Interview;
import org.cts.util.DButil;


public class InterviewDaoIMPL implements InterviewDao {
	
	@Override
	public boolean scheduleInterview(Interview interview) throws NumberFormatException, IOException {
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//		System.out.println("Enter the requirement ID: ");
//		
//		int rId = Integer.parseInt(br.readLine());
//		System.out.println(rId);
		
		
		Connection con = null;
		PreparedStatement pst = null;
		boolean isScheduled = false;
		
		try {
			con = DButil.getConnection();
			
			if (con!=null) {
				
				
				pst = con.prepareStatement("select c.CandidateId from candidate c left join requirement r on r.domain=c.domain where r.reqId=?");
				pst.setInt(1, 1);
				ResultSet rs=pst.executeQuery();
				if(rs.next())
				{
					do {
						PreparedStatement pst1 = null;
						pst1 = con.prepareStatement("insert into interview(interviewId, requireId, candidateId, candidateRank, venue, status) values(?,?,?,?,?,?)");
						pst1.setInt(1, interview.getInterviewId());
						pst1.setInt(2, interview.getRequireId());
						pst1.setInt(3, rs.getInt(1));
						pst1.setString(4, Test.canRank);
						pst1.setString(5, interview.getVenue());
						pst1.setInt(6, interview.getStatus());
						int a = pst1.executeUpdate();
						if(a>0)
						{
							isScheduled=true;
						}
						
					} while (rs.next());
				}
			}
		} catch (Exception e) {
			if(con!=null)
			{
				try{
					con.close();
				}catch(SQLException e1)
				{
					e1.printStackTrace();
				}
			}
		}
		
		return isScheduled;
	}

}
