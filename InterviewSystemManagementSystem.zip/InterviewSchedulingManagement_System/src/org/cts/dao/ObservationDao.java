package org.cts.dao;

import org.cts.model.Observation;

public interface ObservationDao {
	
	boolean storeObservation(Observation observation);

}
