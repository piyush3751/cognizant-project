package org.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.cts.model.Requirement;
import org.cts.util.DButil;

public class AddRequirementDaoIMPL implements AddRequirementDao {

	@Override
	public boolean addRequire(Requirement requirement) {
		Connection con = null;
		PreparedStatement pst1 = null;
		boolean isAdded = false;
		try {
			con=DButil.getConnection();
			if(con != null)
			{
				pst1 = con.prepareStatement("insert into requirement(requiredVacancies, closingDate, minExperience, domain, priority, employeeId, reqId) values(?,?,?,?,?,?,?)");
				pst1.setString(1, requirement.getRequiredVacancies());
				pst1.setString(2, requirement.getClosingDate());
				pst1.setInt(3, requirement.getMinExperience());
				pst1.setString(4, requirement.getDomain());
				pst1.setString(5, requirement.getPriority());
				pst1.setInt(6, requirement.getEmployeeId());
				pst1.setInt(7, requirement.getReqId());
				int a = pst1.executeUpdate();
				if(a>0)
				{
					isAdded = true;
				}
			}
		} catch (Exception e) {
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		}
		
		return isAdded;
	}

	@Override
	public boolean editRequire(Requirement requirement) {
		Connection con2 = null;
		PreparedStatement pst2 = null;
		boolean isEdited = false;
		try {
			con2 = DButil.getConnection();
			if(con2!=null)
			{
				pst2 = con2.prepareStatement("update requirement set requiredVacancies=?, closingDate=?, minExperience=?, domain=?, priority=?, employeeId=? where reqId=?");
				pst2.setString(1, requirement.getRequiredVacancies());
				pst2.setString(2, requirement.getClosingDate());
				pst2.setInt(3, requirement.getMinExperience());
				pst2.setString(4, requirement.getDomain());
				pst2.setString(5, requirement.getPriority());
				pst2.setInt(6, requirement.getEmployeeId());
				pst2.setInt(7, requirement.getReqId());
				int a = pst2.executeUpdate();
				if(a>0)
				{
					isEdited = true;
				}
			}
		} catch (Exception e) {
			if(con2!=null)
			{
				try {
					con2.close();
				} catch (SQLException e3) {
					e3.printStackTrace();
				}
			}
		}
		return isEdited;
	}

}