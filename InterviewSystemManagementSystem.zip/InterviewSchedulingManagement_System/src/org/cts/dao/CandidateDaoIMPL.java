package org.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.cts.model.Candidate;
import org.cts.util.DButil;

public class CandidateDaoIMPL implements CandidateDao {

	@Override
	public boolean register(Candidate candidate) {
		Connection con = null;
		PreparedStatement pst = null;
		boolean isRegistered = false;
		try {
			con=DButil.getConnection();
			if(con!=null)
			{
				pst = con.prepareStatement("insert into candidate(FirstName,LastName,Password,DOB,Address,City,State,Pincode,ContactNo,HighestDegree,YearOfPassing,Marks,Email,Domain,ExperienceYears,History) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				pst.setString(1, candidate.getFirstName());
				pst.setString(2, candidate.getLastName());
				pst.setString(3, candidate.getPassword());
				pst.setString(4, candidate.getdOB());
				pst.setString(5, candidate.getAddress());
				pst.setString(6, candidate.getCity());
				pst.setString(7, candidate.getState());
				pst.setInt(8, candidate.getPincode());
				pst.setString(9, candidate.getContactNo());
				pst.setString(10, candidate.getHighestDegree());
				pst.setInt(11, candidate.getYearOfPassing());
				pst.setString(12, candidate.getMarks());
				pst.setString(13, candidate.getEmail());
				pst.setString(14, candidate.getDomain());
				pst.setInt(15, candidate.getExperienceYears());
				pst.setString(16, candidate.getHistory());
				int a = pst.executeUpdate();
				if(a>0)
				{
					isRegistered = true;
				}
			}
		} catch (Exception e) {
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		}
		
		return isRegistered;
	}

}