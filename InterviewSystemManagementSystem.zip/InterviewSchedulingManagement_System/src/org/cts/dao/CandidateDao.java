package org.cts.dao;

import org.cts.model.Candidate;

public interface CandidateDao {
	boolean register(Candidate candidate);
}