package org.cts.dao;

import java.io.IOException;

import org.cts.model.Interview;

public interface InterviewDao {
	boolean scheduleInterview(Interview interview) throws NumberFormatException, IOException;
}
