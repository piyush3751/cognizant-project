package org.cts.dao;

import org.cts.model.Requirement;

public interface AddRequirementDao {

	boolean addRequire(Requirement requirement);
	boolean editRequire(Requirement requirement);

}