package org.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.cts.model.Observation;
import org.cts.util.DButil;

public class ObservationDaoIMPL implements ObservationDao {

	@Override
	public boolean storeObservation(Observation observation) {
		
		Connection con = null;
		PreparedStatement pst = null;
		boolean isStored = false;
		
		
		try {
			con = DButil.getConnection();
			
			if(con!=null)
			{
				pst = con.prepareStatement("insert into observation(requirementId, interviewId, interviewMarks, noticePeriod) values(?,?,?,?)");
				pst.setInt(1, observation.getRequirementId());
				pst.setInt(2, observation.getInterviewId());
				pst.setInt(3, observation.getInterviewMarks());
				pst.setString(4, observation.getNoticePeriod());
				int a = pst.executeUpdate();
				if(a>0)
				{
					isStored = true;
				}
			}
		} catch (Exception e) {
			if(con!=null)
			{
				try{
					con.close();
				}catch(SQLException e1)
				{
					e1.printStackTrace();
				}
			}
		}
		
		return isStored;
	}

	

}
