package org.cts.util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DButil {
	private static Connection con=null;
	private static Properties properties = new Properties();
	
	public static Connection getConnection() throws ClassNotFoundException, SQLException
	{
		
		try {
			FileInputStream fileInputStream = new FileInputStream("DB.properties");
			properties.load(fileInputStream);
			
			
			Class.forName(properties.getProperty("DRIVER"));
			con = DriverManager.getConnection(properties.getProperty("URL"), properties.getProperty("UNAME"), properties.getProperty("PASSWORD"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
}