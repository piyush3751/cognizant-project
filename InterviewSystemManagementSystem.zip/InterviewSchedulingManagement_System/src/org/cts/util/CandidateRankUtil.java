package org.cts.util;

import java.util.Scanner;

public class CandidateRankUtil {
	
	
	public static int mrks;
	public static String degree;
	
	
	public static String calcRank() {
//		int mrks = Integer.parseInt(candidate.getMarks());
//		String degree = candidate.getHighestDegree();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter highest degree(BE/BTECH/MCA/OTHER) of the candidate: ");
		degree = scanner.nextLine();
		System.out.println("Enter marks of the candidate : ");
		mrks = scanner.nextInt();
		scanner.close();
		
		if(degree=="BE"||degree=="BTECH"||degree=="MCA")
		{
			if (mrks>=90) {
				return "R1";
			}
			else if (mrks>=80 && mrks<90) {
				return "R2";
			}
			else if (mrks>=70 && mrks<80) {
				return "R3";
			}
			else {
				return "R4";
			}
		}
		else {
			if (mrks>=90) {
				return "R2";
			}
			else if (mrks>=80) {
				return "R3";
			}
			else {
				return "R4";
			}
		}
		
		
	}
}
