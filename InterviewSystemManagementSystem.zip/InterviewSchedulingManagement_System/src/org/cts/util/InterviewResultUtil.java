package org.cts.util;

//import java.util.Scanner;

import org.cts.Test;

public class InterviewResultUtil {
	public static int status;
	public String result() {
//		Scanner sc = new Scanner(System.in);
		
		String result = "";
		
		//System.out.println("Enter interview marks: ");
		int marks = CandidateRankUtil.mrks;
		
		String rank = Test.canRank;
		//sc.close();
		
		if(marks<50)
		{
			result = "Rejected";
			status = 0;
		}
		else if (marks>=50 && marks<70) {
			if(rank=="R1")
			{
				result = "Selected";
				status = 1;
			}
			else {
				result = "Rejected";
				status = 0;
			}
		}
		else if (marks>=70 && marks<80) {
			if(rank=="R1" || rank=="R2")
			{
				result = "Selected";
				status = 1;
			}
			else {
				result = "Rejected";
				status = 0;
			}
		}
		else if(marks>=80){
			result = "Selected";
			status = 1;
		}
		
		return result;
	}

}
