package org.cts.util;

import org.cts.model.Requirement;

public class InterviewModeUtil {
	
	public String modeOfInterview(Requirement requirement) {
		int vacancies = Integer.parseInt(requirement.getRequiredVacancies());
		int minExp = requirement.getMinExperience();
		String mode = "";
		
		if(vacancies>0 && vacancies <=3)
		{
			if(minExp<=3)
				mode="Online Test";
			else if(minExp >3 && minExp<=6)
				mode="In person";
			else
				mode="Telephonic";
		}else
		{
			if(minExp<=3)
				mode="Online Test";
			else if(minExp >3 && minExp<=6)
				mode="Online Test";
			else
				mode="In Person";
		}
		
		return mode;
	}
}
