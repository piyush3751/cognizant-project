package org.cts.model;

public class Observation {
	private int requirementId;
	private int interviewId;
	private int interviewMarks;
	private String interviewResult;
	private String noticePeriod;
	private int status;
	
	
	public Observation(String interviewResult) {
		super();
		this.interviewResult = interviewResult;
	}


	public Observation(int status) {
		super();
		this.status = status;
	}




	public Observation(int requirementId, int interviewId, int interviewMarks, String noticePeriod) {
		super();
		this.requirementId = requirementId;
		this.interviewId = interviewId;
		this.interviewMarks = interviewMarks;
		this.noticePeriod = noticePeriod;
	}


	public int getRequirementId() {
		return requirementId;
	}


	public void setRequirementId(int requirementId) {
		this.requirementId = requirementId;
	}


	public int getInterviewId() {
		return interviewId;
	}


	public void setInterviewId(int interviewId) {
		this.interviewId = interviewId;
	}
	

	public int getInterviewMarks() {
		return interviewMarks;
	}


	public void setInterviewMarks(int interviewMarks) {
		this.interviewMarks = interviewMarks;
	}


	public String getInterviewResult() {
		return interviewResult;
	}


	public void setInterviewResult(String interviewResult) {
		this.interviewResult = interviewResult;
	}


	public String getNoticePeriod() {
		return noticePeriod;
	}


	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}


	public int getStatus() {
		return status;
	}


	public void setStatus(int status) {
		this.status = status;
	}
	
	

}
