package org.cts.model;


public class Interview {
	private int interviewId;
	private int requireId;
	private String venue;
	private int status;
	
//	public Interview(int requireId)
//	{
//		super();
//		this.requireId = requireId;
//	}

	public Interview(int interviewId, int requireId, String venue, int status) {
		super();
		this.interviewId = interviewId;
		this.requireId = requireId;
		this.venue = venue;
		this.status = status;
	}

	public int getInterviewId() {
		return interviewId;
	}

	public void setInterviewId(int interviewId) {
		this.interviewId = interviewId;
	}

	public int getRequireId() {
		return requireId;
	}

	public void setRequireId(int requireId) {
		this.requireId = requireId;
	}

	public String getVenue() {
		return venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	
	
	

}
