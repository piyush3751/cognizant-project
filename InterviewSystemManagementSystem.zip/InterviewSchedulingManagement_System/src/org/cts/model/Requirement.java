package org.cts.model;

public class Requirement {
	private String requiredVacancies;
	private String closingDate;
	private int minExperience;
	private String domain;
	private String priority;
	private int employeeId;
	private int reqId;
	
	
	public Requirement(String requiredVacancies, String closingDate, int minExperience, String domain, String priority,
			int employeeId, int reqId) {
		super();
		this.requiredVacancies = requiredVacancies;
		this.closingDate = closingDate;
		this.minExperience = minExperience;
		this.domain = domain;
		this.priority = priority;
		this.employeeId = employeeId;
		this.reqId = reqId;
	}


	public String getRequiredVacancies() {
		return requiredVacancies;
	}


	public void setRequiredVacancies(String requiredVacancies) {
		this.requiredVacancies = requiredVacancies;
	}


	public String getClosingDate() {
		return closingDate;
	}


	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}


	public int getMinExperience() {
		return minExperience;
	}


	public void setMinExperience(int minExperience) {
		this.minExperience = minExperience;
	}


	public String getDomain() {
		return domain;
	}


	public void setDomain(String domain) {
		this.domain = domain;
	}


	public String getPriority() {
		return priority;
	}


	public void setPriority(String priority) {
		this.priority = priority;
	}


	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public int getReqId() {
		return reqId;
	}


	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	
	
	
	
}