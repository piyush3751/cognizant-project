package org.cts.model;

public class Candidate {
	
	private String firstName;
	private String lastName;
	private String password;
	private String dOB;
	private String address;
	private String city;
	private String state;
	private int pincode;
	private String contactNo;
	private String highestDegree;
	private int yearOfPassing;
	private String marks;
	private String email;
	private String domain;
	private int experienceYears;
	private String history;
	

	public Candidate(String firstName, String lastName, String password, String dOB, String address, String city,
			String state, int pincode, String contactNo, String highestDegree, int yearOfPassing, String marks,
			String email, String domain, int experienceYears, String history) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.dOB = dOB;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.contactNo = contactNo;
		this.highestDegree = highestDegree;
		this.yearOfPassing = yearOfPassing;
		this.marks = marks;
		this.email = email;
		this.domain = domain;
		this.experienceYears = experienceYears;
		this.history = history;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getdOB() {
		return dOB;
	}

	public void setdOB(String dOB) {
		this.dOB = dOB;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getHighestDegree() {
		return highestDegree;
	}

	public void setHighestDegree(String highestDegree) {
		this.highestDegree = highestDegree;
	}

	public int getYearOfPassing() {
		return yearOfPassing;
	}

	public void setYearOfPassing(int yearOfPassing) {
		this.yearOfPassing = yearOfPassing;
	}

	public String getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public int getExperienceYears() {
		return experienceYears;
	}

	public void setExperienceYears(int experienceYears) {
		this.experienceYears = experienceYears;
	}

	public String getHistory() {
		return history;
	}

	public void setHistory(String history) {
		this.history = history;
	}

	
	
	
}